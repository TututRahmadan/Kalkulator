package com.example.kalkulator;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recyclerViewAdapter extends RecyclerView.Adapter <recyclerViewAdapter.ViewHolder>{

    private ArrayList<Record>data;

    public recyclerViewAdapter(ArrayList<Record>data) {
        this.data=data;
    }

    @NonNull
    @Override
    public recyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_record, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull recyclerViewAdapter.ViewHolder holder, int position) {
        holder.txtHasil.setText(data.get(position).getHasil());
    }

    @Override
    public int getItemCount() {
        return data!=null?data.size():0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtHasil;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtHasil=itemView.findViewById(R.id.hasil);
        }
    }
}
