package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Record>data;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager recyclerViewLayoutManager=new LinearLayoutManager(this);

    private EditText input1;
    private EditText input2;
    private TextView Hasil;
    private Button hitung;
    private RadioButton tambah;
    private RadioButton kurang;
    private RadioButton kali;
    private RadioButton bagi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=(RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(recyclerViewLayoutManager);
        recyclerViewAdapter adapter = new recyclerViewAdapter(data);
        recyclerView.setAdapter(adapter);

        input1=(EditText) findViewById(R.id.input1);
        input2=(EditText) findViewById(R.id.input2);
        Hasil=(TextView) findViewById(R.id.hasil);
        RadioGroup group = (RadioGroup) findViewById(R.id.radioGroup);
        tambah=(RadioButton) findViewById(R.id.tambah);
        kurang=(RadioButton) findViewById(R.id.kurang);
        kali=(RadioButton)  findViewById(R.id.kali);
        bagi=(RadioButton) findViewById(R.id.bagi);
        hitung=(Button) findViewById(R.id.buttonHitung);
    }

    OnCheckedChangeListener listener = new OnCheckedChangeListener(){

        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (tambah.isChecked()){
                int n1=Integer.parseInt(input1.getText().toString());
                int n2=Integer.parseInt(input2.getText().toString());
                int hasil=n1+n2;

                if (hitung.callOnClick()){
                    Hasil.setText(String.valueOf(hasil));
                    data.add(new Record(hasil));
                }
            }

            else if (kurang.isChecked()){
                int n1=Integer.parseInt(input1.getText().toString());
                int n2=Integer.parseInt(input2.getText().toString());
                int hasil=n1-n2;

                if (hitung.callOnClick()){
                    Hasil.setText(String.valueOf(hasil));
                    data.add(new Record(hasil));
                }
            }

            else if (kali.isChecked()){
                int n1=Integer.parseInt(input1.getText().toString());
                int n2=Integer.parseInt(input2.getText().toString());
                int hasil=n1*n2;

                if (hitung.callOnClick()){
                    Hasil.setText(String.valueOf(hasil));
                    data.add(new Record(hasil));
                }
            }

            else if (bagi.isChecked()) {
                int n1 = Integer.parseInt(input1.getText().toString());
                int n2 = Integer.parseInt(input2.getText().toString());
                int hasil = n1 / n2;

                if (hitung.callOnClick()){
                    Hasil.setText(String.valueOf(hasil));
                    data.add(new Record(hasil));
                }
            }
            group.setOnCheckedChangeListener(listener);
    }};
}
