package com.example.kalkulator;

public class Record {
    int hasil;

    public Record(int hasil){
        this.hasil=hasil;
    }
    public int getHasil(){
        return hasil;
    }
}
